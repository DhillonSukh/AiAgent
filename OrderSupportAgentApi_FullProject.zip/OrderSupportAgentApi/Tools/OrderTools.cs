namespace OrderSupportAgentApi.Tools;

public sealed class OrderTools
{
    private static readonly Dictionary<string, OrderRecord> Orders = new(StringComparer.OrdinalIgnoreCase)
    {
        ["12345"] = new("12345", "Dispatched", false, "The order has left the distribution centre."),
        ["23456"] = new("23456", "Processing", true, "The order is being prepared and has not been dispatched."),
        ["34567"] = new("34567", "Delivered", false, "The order was delivered.")
    };

    public OrderRecord? GetOrderStatus(string orderId)
    {
        if (string.IsNullOrWhiteSpace(orderId) || orderId.Length > 30) return null;
        return Orders.TryGetValue(orderId, out var order) ? order : null;
    }

    // Checks eligibility only; this demo does not perform cancellation.
    public CancellationEligibility CheckCancellationEligibility(string orderId)
    {
        var order = GetOrderStatus(orderId);
        if (order is null) return new(orderId, false, "Order not found.");
        return new(order.OrderId, order.CancellationAllowed,
            order.CancellationAllowed
                ? "Order is still processing and may be eligible for cancellation."
                : $"Order status is {order.Status}; cancellation is not available through this demo.");
    }
}
public sealed record OrderRecord(string OrderId, string Status, bool CancellationAllowed, string Details);
public sealed record CancellationEligibility(string OrderId, bool Eligible, string Explanation);
