namespace OrderSupportAgentApi.Tools;

public sealed class PolicyTools
{
    private static readonly PolicySnippet[] Policies =
    [
        new("RefundPolicy.pdf", "Damaged products may be eligible for a refund. Customers should provide proof of purchase and contact customer support for assessment."),
        new("ReturnsPolicy.pdf", "Eligible products can generally be returned within 30 days, subject to product condition and the applicable policy."),
        new("DeliveryPolicy.pdf", "Delivery estimates depend on the delivery option and location. Customers can check their order status for the latest available information.")
    ];

    public IReadOnlyList<PolicySnippet> SearchPolicies(string query)
    {
        if (string.IsNullOrWhiteSpace(query)) return [];
        var terms = query.Split(' ', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
            .Select(t => t.Trim('.', ',', '?', '!', ':', ';', '"', '\''))
            .Where(t => t.Length > 2).Distinct(StringComparer.OrdinalIgnoreCase).ToArray();
        return Policies.Select(p => new {
                Policy = p,
                Score = terms.Count(term => p.Text.Contains(term, StringComparison.OrdinalIgnoreCase) ||
                                            p.Source.Contains(term, StringComparison.OrdinalIgnoreCase))
            })
            .Where(x => x.Score > 0).OrderByDescending(x => x.Score).Take(3)
            .Select(x => x.Policy).ToArray();
    }
}
public sealed record PolicySnippet(string Source, string Text);
