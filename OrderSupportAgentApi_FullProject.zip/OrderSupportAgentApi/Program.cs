using OrderSupportAgentApi.Services;
using OrderSupportAgentApi.Tools;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddHttpClient<GeminiAgentService>();
builder.Services.AddSingleton<OrderTools>();
builder.Services.AddSingleton<PolicyTools>();
var app = builder.Build();
app.UseSwagger();
app.UseSwaggerUI();
app.MapControllers();
app.MapGet("/", () => Results.Redirect("/swagger"));
app.Run();
