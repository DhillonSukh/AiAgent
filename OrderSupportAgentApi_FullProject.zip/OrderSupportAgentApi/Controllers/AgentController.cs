using Microsoft.AspNetCore.Mvc;
using OrderSupportAgentApi.Models;
using OrderSupportAgentApi.Services;

namespace OrderSupportAgentApi.Controllers;

[ApiController]
[Route("api/agent")]
public sealed class AgentController : ControllerBase
{
    private readonly GeminiAgentService _agent;
    public AgentController(GeminiAgentService agent) => _agent = agent;

    [HttpPost("ask")]
    [ProducesResponseType<AgentResponse>(StatusCodes.Status200OK)]
    public async Task<ActionResult<AgentResponse>> Ask([FromBody] AgentRequest request, CancellationToken ct)
    {
        try
        {
            var result = await _agent.RunAsync(request.Message, ct);
            return Ok(new AgentResponse(result.Answer, result.ToolsUsed, result.ModelTurns));
        }
        catch (ArgumentException ex)
        {
            return BadRequest(new ProblemDetails { Title = "Invalid tool input", Detail = ex.Message, Status = 400 });
        }
        catch (InvalidOperationException ex)
        {
            return StatusCode(500, new ProblemDetails { Title = "Agent configuration error", Detail = ex.Message, Status = 500 });
        }
        catch (HttpRequestException)
        {
            return StatusCode(502, new ProblemDetails {
                Title = "AI model request failed",
                Detail = "The AI provider request failed. Check application logs and provider configuration.",
                Status = 502
            });
        }
    }
}
