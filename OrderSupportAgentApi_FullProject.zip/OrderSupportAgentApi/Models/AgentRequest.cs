using System.ComponentModel.DataAnnotations;
namespace OrderSupportAgentApi.Models;
public sealed class AgentRequest
{
    [Required, StringLength(4000, MinimumLength = 1)]
    public string Message { get; init; } = string.Empty;
}
