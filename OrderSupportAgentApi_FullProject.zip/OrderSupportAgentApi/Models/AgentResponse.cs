namespace OrderSupportAgentApi.Models;
public sealed record AgentResponse(string Answer, IReadOnlyList<string> ToolsUsed, int ModelTurns);
