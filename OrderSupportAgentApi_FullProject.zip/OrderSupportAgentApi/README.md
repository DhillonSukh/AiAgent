# Order Support Agent API — .NET 8 + Gemini function calling

A learning project demonstrating an agent loop:
1. Send the user message and tool declarations to Gemini.
2. If Gemini requests a function, validate arguments and execute allow-listed C# code.
3. Send function results back to Gemini.
4. Repeat until Gemini returns a final text answer or the turn limit is reached.

## Requirements
- .NET 8 SDK
- Gemini API key / Generative Language API access
- Network access to generativelanguage.googleapis.com

## Set the API key (don't commit it)
PowerShell:
```powershell
$env:GEMINI_API_KEY = "YOUR_API_KEY"
dotnet run
```
Command Prompt:
```cmd
set GEMINI_API_KEY=YOUR_API_KEY
dotnet run
```

## Run
```bash
dotnet restore
dotnet build
dotnet run
```
Open `http://localhost:5080/swagger`.

## Try POST /api/agent/ask
```json
{ "message": "Where is order 12345, and can I cancel it?" }
```
Try also:
- `What is the status of order 23456?`
- `What should a customer do if a product is damaged?`
- `Explain the delivery policy.`
- `What is order 99999 status?`

Response fields: `answer`, `toolsUsed`, and `modelTurns`.

## Available tools
- `get_order_status(orderId)` — reads demo order data.
- `check_cancellation_eligibility(orderId)` — checks only; does not cancel.
- `search_policies(query)` — keyword-searches sample policy snippets.

The model requests a tool; the C# application owns and executes the tool. Never execute model-generated code. Validate arguments and enforce authorization in trusted backend code. Before any real write operation, add authorization, audit logging, idempotency, approval/confirmation, and robust error handling.

## Limitations
- This is a learning prototype, not production-ready.
- Order data is mocked in memory and resets on restart.
- Policy search is keyword matching, not your previous vector-based RAG index.
- The model may choose different tools on different runs.
- Production requires rate limits, retries/backoff, telemetry, timeout policies, security review, and automated tests.
- The project has not been compile-verified in your environment; run `dotnet build` and share any errors.
